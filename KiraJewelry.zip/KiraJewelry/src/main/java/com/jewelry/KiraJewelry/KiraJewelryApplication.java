package com.jewelry.KiraJewelry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KiraJewelryApplication {

	public static void main(String[] args) {
		SpringApplication.run(KiraJewelryApplication.class, args);
	}

}
