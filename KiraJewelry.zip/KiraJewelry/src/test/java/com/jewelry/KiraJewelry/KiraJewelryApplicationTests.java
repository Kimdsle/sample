package com.jewelry.KiraJewelry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KiraJewelryApplicationTests {

	@Test
	void contextLoads() {
	}

}
